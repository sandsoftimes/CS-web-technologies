// App.js
import React, { useState } from 'react';
import './App.css'; // External stylesheet for styles

const App = () => {
  const [notes, setNotes] = useState([]);
  const [currentNote, setCurrentNote] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const addNote = () => {
    if (currentNote.trim() !== '') {
      setNotes([...notes, currentNote]);
      setCurrentNote('');
    }
  };

  const editNote = (index) => {
    setCurrentNote(notes[index]);
    setIsEditing(true);
  };

  const updateNote = () => {
    if (currentNote.trim() !== '') {
      const updatedNotes = [...notes];
      updatedNotes[notes.indexOf(currentNote)] = currentNote;
      setNotes(updatedNotes);
      setCurrentNote('');
      setIsEditing(false);
    }
  };

  const deleteNote = (index) => {
    const updatedNotes = [...notes];
    updatedNotes.splice(index, 1);
    setNotes(updatedNotes);
  };

  return (
    <div className="App">
      <h1>Note-Taking App</h1>
      <div>
        <input
          type="text"
          value={currentNote}
          onChange={(e) => setCurrentNote(e.target.value)}
          placeholder="Enter your note"
        />
        {isEditing ? (
          <button onClick={updateNote}>Update Note</button>
        ) : (
          <button onClick={addNote}>Add Note</button>
        )}
      </div>
      <ul>
        {notes.map((note, index) => (
          <li key={index}>
            <span onClick={() => editNote(index)}>{note}</span>
            <button onClick={() => deleteNote(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
